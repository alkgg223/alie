package com.example.gunsmod;

public enum GunType {
    //        id        dmg   mag delay reload spread pel range auto   zoom  pitch recoil snd heavy  scoped explosive
    PISTOL ("pistol",   5.0f,  15,  6,  40, 1.5f, 1,  64, false, 0.85f, 1.6f, 1.2f, 0, false, false, 0f),
    DEAGLE ("deagle",   9.0f,   7, 14,  50, 1.0f, 1,  80, false, 0.80f, 1.0f, 3.5f, 1, false, false, 0f),
    SMG    ("smg",      3.0f,  30,  2,  50, 3.5f, 1,  48, true,  0.85f, 1.9f, 0.8f, 0, false, false, 0f),
    RIFLE  ("rifle",    5.0f,  30,  3,  60, 2.2f, 1,  96, true,  0.70f, 1.2f, 1.6f, 1, false, false, 0f),
    M4     ("m4",       4.0f,  30,  3,  55, 1.6f, 1, 100, true,  0.70f, 1.4f, 1.0f, 1, false, false, 0f),
    SHOTGUN("shotgun",  2.5f,   6, 20,  70, 7.0f, 8,  24, false, 0.85f, 0.8f, 4.0f, 2, false, false, 0f),
    SNIPER ("sniper",  22.0f,   5, 40,  80, 0.1f, 1, 200, false, 0.20f, 0.6f, 5.0f, 2, false, true,  0f),
    LMG    ("lmg",      4.0f, 100,  3, 140, 3.0f, 1,  90, true,  0.80f, 1.0f, 1.4f, 1, true,  false, 0f),
    RPG    ("rpg",      6.0f,   1, 40,  90, 0.5f, 1, 120, false, 0.60f, 0.7f, 6.0f, 2, true,  false, 3.5f),
    MINIGUN("minigun",  2.5f, 150,  1, 160, 5.0f, 1,  70, true,  0.85f, 1.1f, 0.6f, 1, true,  false, 0f);

    public final String id;
    public final float damage;
    public final int magSize;
    public final int fireDelay;
    public final int reloadTicks;
    public final float spread;
    public final int pellets;
    public final double range;
    public final boolean automatic;
    public final float zoom;
    public final float pitch;
    public final float recoil;
    public final int sound;        // 0 light, 1 medium, 2 heavy
    public final boolean heavy;    // slows you even when walking
    public final boolean scoped;   // sniper scope overlay when aiming
    public final float explosive;  // explosion power at impact (0 = none)

    GunType(String id, float damage, int magSize, int fireDelay, int reloadTicks, float spread,
            int pellets, double range, boolean automatic, float zoom, float pitch,
            float recoil, int sound, boolean heavy, boolean scoped, float explosive) {
        this.id = id;
        this.damage = damage;
        this.magSize = magSize;
        this.fireDelay = fireDelay;
        this.reloadTicks = reloadTicks;
        this.spread = spread;
        this.pellets = pellets;
        this.range = range;
        this.automatic = automatic;
        this.zoom = zoom;
        this.pitch = pitch;
        this.recoil = recoil;
        this.sound = sound;
        this.heavy = heavy;
        this.scoped = scoped;
        this.explosive = explosive;
    }
}
