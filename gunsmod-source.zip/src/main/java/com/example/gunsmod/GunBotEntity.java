package com.example.gunsmod;

import java.util.EnumSet;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class GunBotEntity extends PathfinderMob {
    private static final EntityDataAccessor<Boolean> ALLY =
            SynchedEntityData.defineId(GunBotEntity.class, EntityDataSerializers.BOOLEAN);

    private UUID ownerUUID;
    private int ammo;
    private int reloadTicks;
    private int shootCooldown;

    public GunBotEntity(EntityType<? extends GunBotEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.setDropChance(EquipmentSlot.MAINHAND, 2.0f);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 30.0)
                .add(Attributes.MOVEMENT_SPEED, 0.28)
                .add(Attributes.FOLLOW_RANGE, 40.0)
                .add(Attributes.ARMOR, 2.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(ALLY, true);
    }

    // ------------------------------------------------------------ team
    public boolean isAlly() {
        return this.entityData.get(ALLY);
    }

    public void setAlly(boolean ally, UUID owner) {
        this.entityData.set(ALLY, ally);
        this.ownerUUID = ally ? owner : null;
        this.setTarget(null);
    }

    public UUID getOwnerUUID() {
        return ownerUUID;
    }

    public Player getOwner() {
        return ownerUUID == null ? null : this.level().getPlayerByUUID(ownerUUID);
    }

    public GunItem getGun() {
        return this.getMainHandItem().getItem() instanceof GunItem g ? g : null;
    }

    /** Entities this bot must never shoot or target. */
    public boolean isFriendly(Entity e) {
        if (e == this) return true;
        if (isAlly()) {
            if (ownerUUID != null && ownerUUID.equals(e.getUUID())) return true;
            return e instanceof GunBotEntity b && b.isAlly();
        }
        return e instanceof GunBotEntity b && !b.isAlly();
    }

    public boolean isHostileTo(LivingEntity e) {
        if (e == this || !e.isAlive() || isFriendly(e)) return false;
        if (isAlly()) {
            return e instanceof Enemy || (e instanceof GunBotEntity b && !b.isAlly());
        }
        return (e instanceof Player p && !p.isSpectator()) || (e instanceof GunBotEntity b && b.isAlly());
    }

    @Override
    public void setTarget(LivingEntity target) {
        if (target != null && isFriendly(target)) return;
        super.setTarget(target);
    }

    // ------------------------------------------------------------ AI
    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new AttackGoal(this));
        this.goalSelector.addGoal(2, new FollowOwnerGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0f));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, LivingEntity.class, 10, true, false, this::isHostileTo));
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) return;
        if (shootCooldown > 0) shootCooldown--;
        if (reloadTicks > 0 && --reloadTicks == 0) {
            GunItem g = getGun();
            if (g != null) ammo = g.type.magSize;
        }
        if (isAlly() && this.tickCount % 10 == 0 && getTarget() == null) {
            Player owner = getOwner();
            if (owner != null) {
                LivingEntity a = owner.getLastHurtByMob();
                if (a != null && a.isAlive() && !isFriendly(a)
                        && owner.tickCount - owner.getLastHurtByMobTimestamp() < 100) {
                    setTarget(a);
                } else {
                    LivingEntity b = owner.getLastHurtMob();
                    if (b != null && b.isAlive() && isHostileTo(b)
                            && owner.tickCount - owner.getLastHurtMobTimestamp() < 100) {
                        setTarget(b);
                    }
                }
            }
        }
    }

    public void tryShoot(LivingEntity target) {
        GunItem gun = getGun();
        if (gun == null || !(this.level() instanceof ServerLevel sl) || !target.isAlive()) return;
        if (reloadTicks > 0 || shootCooldown > 0) return;
        if (ammo <= 0) {
            reloadTicks = gun.type.reloadTicks;
            sl.playSound(null, getX(), getY(), getZ(), SoundEvents.IRON_TRAPDOOR_OPEN, SoundSource.HOSTILE, 0.8f, 1.4f);
            return;
        }
        Vec3 origin = getEyePosition();
        Vec3 aim = target.position().add(0, target.getBbHeight() * 0.7, 0);
        Vec3 dir = aim.subtract(origin).normalize();
        GunItem.shoot(sl, this, origin, dir, gun.type, false, 0.8f, 1.5f, this::isFriendly);
        ammo--;
        shootCooldown = Math.max(gun.type.fireDelay, 6) + (gun.type.fireDelay < 20 ? getRandom().nextInt(6) : 0);
    }

    // ------------------------------------------------------------ interaction
    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (held.getItem() instanceof GunItem gun) {
            if (!this.level().isClientSide) {
                ItemStack old = this.getMainHandItem().copy();
                this.setItemSlot(EquipmentSlot.MAINHAND, held.copyWithCount(1));
                this.ammo = gun.type.magSize;
                this.reloadTicks = 0;
                if (!player.getAbilities().instabuild) held.shrink(1);
                if (!old.isEmpty()) player.getInventory().placeItemBackInInventory(old);
                player.displayClientMessage(Component.literal("Bot equipped: ").append(held.getHoverName()), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        if (held.isEmpty()) {
            if (!this.level().isClientSide) {
                if (player.isShiftKeyDown()) {
                    boolean nowAlly = !isAlly();
                    setAlly(nowAlly, player.getUUID());
                    player.displayClientMessage(Component.literal(nowAlly ? "Bot is now ALLY" : "Bot is now ENEMY"), true);
                } else {
                    GunItem g = getGun();
                    player.displayClientMessage(Component.literal((isAlly() ? "Ally" : "Enemy") + " bot | Gun: "
                            + (g == null ? "none" : g.type.id) + " | Sneak+click to switch team"), true);
                }
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    // ------------------------------------------------------------ save
    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Ally", isAlly());
        if (ownerUUID != null) tag.putUUID("Owner", ownerUUID);
        tag.putInt("BotAmmo", ammo);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Ally")) this.entityData.set(ALLY, tag.getBoolean("Ally"));
        if (tag.hasUUID("Owner")) ownerUUID = tag.getUUID("Owner");
        ammo = tag.getInt("BotAmmo");
    }

    // ------------------------------------------------------------ goals
    static class AttackGoal extends Goal {
        private final GunBotEntity bot;
        private int repath;

        AttackGoal(GunBotEntity bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity t = bot.getTarget();
            return t != null && t.isAlive() && bot.getGun() != null;
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void start() {
            bot.setAggressive(true);
        }

        @Override
        public void stop() {
            bot.setAggressive(false);
            bot.getNavigation().stop();
        }

        @Override
        public void tick() {
            LivingEntity t = bot.getTarget();
            GunItem gun = bot.getGun();
            if (t == null || gun == null) return;
            double dist = bot.distanceTo(t);
            boolean see = bot.getSensing().hasLineOfSight(t);
            bot.getLookControl().setLookAt(t, 30f, 30f);
            double ideal = Math.min(gun.type.range * 0.5, 16.0);
            if (see && dist <= ideal) {
                bot.getNavigation().stop();
            } else if (--repath <= 0) {
                repath = 10;
                bot.getNavigation().moveTo(t, 1.1);
            }
            if (see && dist <= Math.min(gun.type.range, 40.0)) {
                bot.tryShoot(t);
            }
        }
    }

    static class FollowOwnerGoal extends Goal {
        private final GunBotEntity bot;
        private int repath;

        FollowOwnerGoal(GunBotEntity bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (!bot.isAlly() || bot.getTarget() != null) return false;
            Player o = bot.getOwner();
            return o != null && bot.distanceToSqr(o) > 64.0;
        }

        @Override
        public boolean canContinueToUse() {
            if (!bot.isAlly() || bot.getTarget() != null) return false;
            Player o = bot.getOwner();
            return o != null && bot.distanceToSqr(o) > 12.0;
        }

        @Override
        public void tick() {
            Player o = bot.getOwner();
            if (o == null) return;
            if (--repath <= 0) {
                repath = 10;
                if (bot.distanceToSqr(o) > 1024.0) {
                    bot.teleportTo(o.getX(), o.getY(), o.getZ());
                } else {
                    bot.getNavigation().moveTo(o, 1.2);
                }
            }
        }
    }
}
