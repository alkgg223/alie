package com.example.gunsmod;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

public record AimPayload(boolean aiming) implements CustomPacketPayload {
    public static final Type<AimPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(GunsMod.MODID, "aim"));
    public static final StreamCodec<ByteBuf, AimPayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.BOOL, AimPayload::aiming, AimPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
